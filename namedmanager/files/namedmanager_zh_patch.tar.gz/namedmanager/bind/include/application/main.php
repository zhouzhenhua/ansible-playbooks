<?php
/*
	NamedManager Application Libraries

	Provides functions for NamedManager.
*/


@log_debug("start", "");
@log_debug("start", "NAMEDMANAGER LIBRARIES LOADED");
@log_debug("start", "");


// include main code functions
require("inc_soap_api.php");
require("inc_bind.php");



?>
