<?php
//
// user/logout-process.php
//
// process user logout.
//

include_once("../include/config.php");
include_once("../include/amberphplib/main.php");


if (user_logout())
{
	$_SESSION["notification"]["message"][] = "您已成功登出.";
	header("Location: ../index.php?page=home.php");
	exit(0);
}
else
{
	$_SESSION["error"]["message"][] = "您不能登出,因为您还未登录!";
	header("Location: ../index.php?page=home.php");
	exit(0);

}

?>
