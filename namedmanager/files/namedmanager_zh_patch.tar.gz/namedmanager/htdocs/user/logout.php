<?php
/*
	user/logout.php

	allows a user to logout of the site.

*/

class page_output
{
	function check_permissions()
	{
		return user_online();
	}

	function check_requirements()
	{
		// nothing todo
		return 1;
	}

	
	function execute()
	{
		// nothing todo
		return 1;
	}


	function render_html()
	{
		/////////////////////////
	
		print "<h3>用户登出</h3>";
		print "<p>为安全起见,点击下面登出按钮,将浏览器session断开.</p>";
	
		print "<form method=\"POST\" action=\"user/logout-process.php\">
		<input type=\"submit\" value=\"Logout\">
		</form>";
		/////////////////////////
	}
}


?>
