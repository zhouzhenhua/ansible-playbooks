-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: namedmanager
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cloud_zone_map`
--

DROP TABLE IF EXISTS `cloud_zone_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_zone_map` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_name_server` int(10) unsigned NOT NULL,
  `id_domain` int(10) unsigned NOT NULL,
  `id_mapped` varchar(255) NOT NULL DEFAULT '',
  `soa_serial` bigint(20) NOT NULL,
  `delegated_ns` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_zone_map`
--

LOCK TABLES `cloud_zone_map` WRITE;
/*!40000 ALTER TABLE `cloud_zone_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_zone_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`name`, `value`) VALUES ('ADMIN_API_KEY','T=fFR/o6LYkyFkyc|3a+'),('APP_MYSQL_DUMP','/usr/bin/mysqldump'),('APP_PDFLATEX','/usr/bin/pdflatex'),('AUTH_METHOD','ldaponly'),('AUTH_PERMS_CACHE','enabled'),('BLACKLIST_ENABLE','enabled'),('BLACKLIST_LIMIT','10'),('DATA_STORAGE_LOCATION','use_database'),('DATA_STORAGE_METHOD','database'),('DATEFORMAT','yyyy-mm-dd'),('DEFAULT_HOSTMASTER','root@devops.local'),('DEFAULT_TTL_MX','600'),('DEFAULT_TTL_NS','86400'),('DEFAULT_TTL_OTHER','600'),('DEFAULT_TTL_SOA','86400'),('FEATURE_LOGS_API','0'),('FEATURE_LOGS_AUDIT','1'),('FEATURE_LOGS_ENABLE','1'),('LANGUAGE_DEFAULT','en_us'),('LANGUAGE_LOAD','preload'),('LOG_RETENTION_CHECKTIME','0'),('LOG_RETENTION_PERIOD','90'),('LOG_UPDATE_INTERVAL','5'),('PAGINATION_DOMAIN_RECORDS','25'),('PATH_TMPDIR','/tmp'),('PHONE_HOME','0'),('PHONE_HOME_TIMER','0'),('SCHEMA_VERSION','20131222'),('SUBSCRIPTION_ID','7622e260239c13ccec40cbff50f93d83'),('SUBSCRIPTION_SUPPORT','opensource'),('SYNC_STATUS_CONFIG','1524289841'),('TIMEZONE_DEFAULT','Asia/Shanghai'),('UPLOAD_MAXBYTES','5242880'),('ZONE_DB_HOST','disabled'),('ZONE_DB_NAME','disabled'),('ZONE_DB_PASSWORD','disabled'),('ZONE_DB_TYPE','zone_internal'),('ZONE_DB_USERNAME','disabled');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dns_domains`
--

DROP TABLE IF EXISTS `dns_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dns_domains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(255) NOT NULL,
  `domain_description` text NOT NULL,
  `soa_hostmaster` varchar(255) NOT NULL DEFAULT '',
  `soa_serial` bigint(20) unsigned NOT NULL DEFAULT '0',
  `soa_refresh` int(10) unsigned NOT NULL DEFAULT '0',
  `soa_retry` int(10) unsigned NOT NULL DEFAULT '0',
  `soa_expire` int(10) unsigned NOT NULL DEFAULT '0',
  `soa_default_ttl` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dns_domains`
--

LOCK TABLES `dns_domains` WRITE;
/*!40000 ALTER TABLE `dns_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `dns_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dns_domains_groups`
--

DROP TABLE IF EXISTS `dns_domains_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dns_domains_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_domain` int(10) unsigned NOT NULL,
  `id_group` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dns_domains_groups`
--

LOCK TABLES `dns_domains_groups` WRITE;
/*!40000 ALTER TABLE `dns_domains_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `dns_domains_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dns_record_types`
--

DROP TABLE IF EXISTS `dns_record_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dns_record_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(6) NOT NULL,
  `user_selectable` tinyint(1) NOT NULL DEFAULT '0',
  `is_standard` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dns_record_types`
--

LOCK TABLES `dns_record_types` WRITE;
/*!40000 ALTER TABLE `dns_record_types` DISABLE KEYS */;
INSERT INTO `dns_record_types` (`id`, `type`, `user_selectable`, `is_standard`) VALUES (1,'SOA',0,0),(2,'NS',0,0),(3,'MX',0,0),(4,'A',1,1),(5,'AAAA',1,1),(6,'PTR',1,0),(7,'CNAME',1,1),(8,'SRV',1,1),(9,'SPF',1,1),(10,'TXT',1,1);
/*!40000 ALTER TABLE `dns_record_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dns_records`
--

DROP TABLE IF EXISTS `dns_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dns_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_domain` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(6) NOT NULL DEFAULT '',
  `content` varchar(255) NOT NULL DEFAULT '',
  `ttl` int(11) NOT NULL DEFAULT '3600',
  `prio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_domain` (`id_domain`)
) ENGINE=InnoDB AUTO_INCREMENT=365 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dns_records`
--

LOCK TABLES `dns_records` WRITE;
/*!40000 ALTER TABLE `dns_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `dns_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_upload_data`
--

DROP TABLE IF EXISTS `file_upload_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_upload_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fileid` int(11) NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table for use as database-backed file storage system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_upload_data`
--

LOCK TABLES `file_upload_data` WRITE;
/*!40000 ALTER TABLE `file_upload_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_upload_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploads`
--

DROP TABLE IF EXISTS `file_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL,
  `timestamp` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `file_location` char(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploads`
--

LOCK TABLES `file_uploads` WRITE;
/*!40000 ALTER TABLE `file_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal`
--

DROP TABLE IF EXISTS `journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `journalname` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0',
  `customid` int(11) NOT NULL DEFAULT '0',
  `timestamp` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `journalname` (`journalname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal`
--

LOCK TABLES `journal` WRITE;
/*!40000 ALTER TABLE `journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(20) NOT NULL,
  `label` varchar(255) NOT NULL,
  `translation` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `language` (`language`),
  KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=633 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` (`id`, `language`, `label`, `translation`) VALUES (292,'en_us','username_namedmanager','Username'),(293,'en_us','password_namedmanager','Password'),(294,'en_us','powerdns_mysql','PowerDNS-compliant MySQL Database (unstable, alpha feature)'),(295,'en_us','domain_records_ns_help','The following is a list of all the nameservers that this domain is managed by.\r\n\r\nThese are auto-populated with the domains configured in the DB, however you can add your own records if you wish to sub-delegate the domain (for example, setting internal.example.com to be handled by another name server)'),(296,'en_us','domain_records_mx_help','Configure all the mailservers for the system here, remember that all mail will be delivered to the server with the lowest priority by default.'),(297,'en_us','domain_records_custom_help','Configure all remaining records here - select the type from the dropdown and enter the suitable values'),(298,'en_us','zone_internal','Use internal application SQL database'),(299,'en_us','server_primary_option_help','Make this server the primary one used for DNS SOA records.'),(300,'en_us','menu_configuration','Configuration'),(301,'en_us','menu_servers','Name Servers'),(302,'en_us','menu_servers_view','View Name Servers'),(303,'en_us','menu_servers_add','Add Name Server'),(304,'en_us','menu_domains','Domains/Zones'),(305,'en_us','menu_domains_view','View Domains'),(306,'en_us','menu_domains_add','Add Domain'),(307,'en_us','menu_overview','Overview'),(308,'en_us','menu_logs','Changelog'),(309,'en_us','tbl_lnk_details','details'),(310,'en_us','tbl_lnk_records','domain records'),(311,'en_us','tbl_lnk_delete','delete'),(312,'en_us','tbl_lnk_delete','delete'),(313,'en_us','tbl_lnk_logs','logs'),(314,'en_us','domain_name','Domain Name'),(315,'en_us','domain_serial','Domain Serial'),(316,'en_us','domain_description','Description'),(317,'en_us','domain_details','Domain Details'),(318,'en_us','domain_soa','Start of Authority Record'),(319,'en_us','soa_hostmaster','Email Administrator Address'),(320,'en_us','soa_serial','Domain Serial'),(321,'en_us','soa_refresh','Refresh Timer'),(322,'en_us','soa_retry','Refresh Retry Timeout'),(323,'en_us','soa_expire','Expiry Timer'),(324,'en_us','soa_default_ttl','Default Record TTL'),(325,'en_us','submit','Save Changes'),(326,'en_us','domain_records_ns','Nameserver Configuration'),(327,'en_us','domain_records_mx','Mailserver Configuration'),(328,'en_us','domain_records_custom','Host Records Configuration'),(329,'en_us','record_type','Type'),(330,'en_us','record_ttl','TTL'),(331,'en_us','record_name','Name'),(332,'en_us','record_content','Content'),(333,'en_us','record_prio','Priority'),(334,'en_us','server_primary','Primary Nameserver'),(335,'en_us','server_name','Name Server FQDN'),(336,'en_us','server_description','Description'),(337,'en_us','server_type','Server Type'),(338,'en_us','sync_status','Sync Status'),(339,'en_us','server_details','Server Details'),(340,'en_us','api_auth_key','API Authentication Key'),(341,'en_us','server_status','Server Status'),(342,'en_us','sync_status_config','Configuration Status'),(343,'en_us','help_api_auth_key','Authentication key to enable bind configuration generation script to talk back to NamedManager.'),(344,'en_us','sync_status_log','Logging Status'),(345,'en_us','api','API (supports Bind)'),(346,'en_us','config_zone_defaults','Zone Configuration Defaults'),(347,'en_us','config_zone_database','Zone Database Defaults'),(348,'en_us','config_dateandtime','Date and Time Configuration'),(349,'en_us','timestamp','Timestamp'),(350,'en_us','username','Username'),(351,'en_us','log_type','Log Type'),(352,'en_us','log_contents','Log Contents'),(353,'en_us','filter_searchbox','Search'),(354,'en_us','filter_num_logs_rows','Maximum Log Lines'),(355,'en_us','filter_id_server_name','Name Server'),(356,'en_us','filter_id_domain','Domain Name'),(357,'en_us','help_ipv4_autofill','Automatically create PTR records for all the IPs in the domain, with the specified domain name suffix.'),(358,'en_us','ipv4_help','Note'),(359,'en_us','help_ipv4_help','This interface allows you to setup a reverse DNS record for a /24 network range, by specifying the network address and optionally a domain for the PTR records if you want all the IP-DNS mapping created automatically.'),(360,'en_us','domain_standard','Standard Domain'),(361,'en_us','domain_reverse_ipv4','Reverse Domain (IPv4)'),(362,'en_us','domain_type','Domain Type'),(363,'en_us','ipv4_network','IPv4 Network Address'),(364,'en_us','ipv4_autofill','Autofill IPs'),(365,'en_us','ipv4_autofill_domain','Autofill IPs with domain'),(366,'en_us','reverse_ptr','Reverse PTR'),(367,'en_us','file_bind_8','Bind 8/9 Compatible Zonefile'),(368,'en_us','menu_domains_import','Import Domain'),(369,'en_us','records_not_imported','Warning: No records were imported into the application!'),(370,'en_us','record_import_guide','All the records that have been processed by NamedManager from the uploaded zonefile are displayed below. Double-check that everything appears correctly - there may be some records that need adjusting, or some that are no longer required (eg old NS records).\n\nYou can check/uncheck the import button to include/exclude records from the import process if they are no longer desired.'),(371,'en_us','domain_delete','Delete Domain'),(372,'en_us','delete_confirm','Confirm Deletion'),(373,'en_us','config_api','API Configuration'),(374,'en_us','config_miscellaneous','Miscellaneous Configuration'),(375,'en_us','domain_records','Domain Records'),(376,'en_us','record_header_type','Type'),(377,'en_us','record_header_ttl','TTL'),(378,'en_us','record_header_prio','Priority'),(379,'en_us','record_header_name','Name/Origin'),(380,'en_us','record_header_content','Content/Record'),(381,'en_us','record_header_import','Import Record?'),(382,'en_us','record_origin','Name/Origin'),(383,'en_us','unmatched_import','Unmatched Records'),(384,'en_us','import_notice_unmatched_rows','Not all records were imported successfully, please review the unmatched lines below - if they are desired, you can adjust the format in the file before upload or create the domain and then add these missed records manually'),(385,'en_us','import_notice_no_unmatched_rows','All records in the zone file have been identified and imported into the array above. :-)'),(386,'en_us','upload','Upload'),(387,'en_us','import_upload_type','Import Source'),(388,'en_us','import_upload_file','Zone File'),(389,'en_us','help_admin_api_key','Key used to authenticate Nameserver-located scripts.'),(390,'en_us','unmatched_import_help','Zonefile import is not always perfect, especially when importing from human-written text zone files. If there are any records that couldn\'t be matched, they will appear below for manual handling.'),(391,'en_us','server_record','Use as NS Record'),(392,'en_us','server_record_option_help','Adds this name server to all domains as a public NS record.'),(393,'en_us','ipv4_autofill_forward','Create Forward Record'),(394,'en_us','help_ipv4_autofill_forward','Automatically creates forward records for each IP in the specified domain.'),(395,'en_us','sync_status_zones','Zonefile Status'),(396,'en_us','ipv4_autofill_reverse_from_forward','Create Records From Existing'),(397,'en_us','help_ipv4_autofill_reverse_from_forward','Automatically find any existing A records for the IP range being added and set the reverse records to them where possible.'),(398,'en_us','help_domain_group_selection','Select the group or groups that this domain belongs to - groups allow domains to be located on specific sets of name servers which is useful for segregation purposes (eg internal vs external name servers).'),(399,'en_us','config_logging','Logging Configuration'),(400,'en_us','domain_groups','Domain Server Groups'),(401,'en_us','server_group','Server Group'),(402,'en_us','menu_servers_groups','Manage Server Groups'),(403,'en_us','menu_servers_groups_view','View Groups'),(404,'en_us','menu_servers_groups_add','Add Group'),(405,'en_us','group_name','Name'),(406,'en_us','group_description','Description'),(407,'en_us','group_members','Server Group Members'),(408,'en_us','group_details','Server Group Details'),(409,'en_us','group_member_servers','Member Name Servers'),(410,'en_us','group_member_domains','Member Domains'),(411,'en_us','group_delete','Delete Group'),(412,'en_us','server_domains','Server Domain Settings'),(413,'en_us','realname','Real Name'),(414,'en_us','contact_email','Contact Email'),(415,'en_us','lastlogin_time','Last Login Time'),(416,'en_us','lastlogin_ipaddress','Last Login Location'),(417,'en_us','tbl_lnk_permissions','permissions'),(418,'en_us','user_permissions','User Permissions'),(419,'en_us','id_user','User ID'),(420,'en_us','user_view','User Details'),(421,'en_us','user_password','User Password'),(422,'en_us','user_info','User Details'),(423,'en_us','user_options','User Options'),(424,'en_us','user_delete','Delete User'),(425,'en_us','menu_admin_users','User Management'),(426,'en_us','domain_reverse_ipv6','Reverse Domain (IPv6)'),(427,'en_us','ipv6_network','IPv6 Network Range'),(428,'en_us','ipv6_help','Note'),(429,'en_us','help_ipv6_help','This interface allows you to setup a reverse DNS record for an IPv6 network range, by specifying the range along with a CIDR value.'),(430,'en_us','id_group','Nameserver Group'),(431,'en_us','config_amberstats','Assist the developers!'),(432,'en_us','config_hosted','Hosted Cloud DNS Services'),(492,'zh_cn','username_namedmanager','用户名'),(493,'zh_cn','password_namedmanager','密码'),(494,'zh_cn','powerdns_mysql','PowerDNS兼容MySQL数据库 （不稳定,alpha功能）'),(495,'zh_cn','domain_records_ns_help','下列这些域名的NS服务器列表是由名称服务器配置界面同步而来，如果您想要分委派域 ，您可以添加您自己的记录，(例如设置 dns2.example.com 的另一个名称服务器处理)'),(496,'zh_cn','domain_records_mx_help','注意，这里配置的所有邮件服务器其解析顺序将从优先级最小的开始。'),(497,'zh_cn','domain_records_custom_help','配置所有剩余的记录—从下拉列表中选择类型并输入合适的值'),(498,'zh_cn','zone_internal','使用内部应用程序的 SQL 数据库'),(499,'zh_cn','server_primary_option_help','使该服务器 DNS SOA 记录中使用的主要的一个。'),(500,'zh_cn','menu_configuration','系统配置'),(501,'zh_cn','menu_servers','名称服务器'),(502,'zh_cn','menu_servers_view','视图名称服务器'),(503,'zh_cn','menu_servers_add','添加名称服务器'),(504,'zh_cn','menu_domains','域管理'),(505,'zh_cn','menu_domains_view','查看域'),(506,'zh_cn','menu_domains_add','添加域'),(507,'zh_cn','menu_overview','概述'),(508,'zh_cn','menu_logs','日志'),(509,'zh_cn','tbl_lnk_details','详细信息'),(510,'zh_cn','tbl_lnk_records','域名记录'),(511,'zh_cn','tbl_lnk_delete','删除'),(512,'zh_cn','tbl_lnk_delete','删除'),(513,'zh_cn','tbl_lnk_logs','日志'),(514,'zh_cn','domain_name','域名'),(515,'zh_cn','domain_serial','域序列'),(516,'zh_cn','domain_description','描述'),(517,'zh_cn','domain_details','域的详细信息'),(518,'zh_cn','domain_soa','起始授权机构记录'),(519,'zh_cn','soa_hostmaster','管理员电子邮件地址'),(520,'zh_cn','soa_serial','域序列'),(521,'zh_cn','soa_refresh','刷新计时器'),(522,'zh_cn','soa_retry','刷新重试超时'),(523,'zh_cn','soa_expire','有效期届满计时器'),(524,'zh_cn','soa_default_ttl','默认记录 TTL'),(525,'zh_cn','submit','保存更改'),(526,'zh_cn','domain_records_ns','名称服务器配置'),(527,'zh_cn','domain_records_mx','邮件服务器配置'),(528,'zh_cn','domain_records_custom','主机记录配置'),(529,'zh_cn','record_type','类型'),(530,'zh_cn','record_ttl','TTL'),(531,'zh_cn','record_name','名称'),(532,'zh_cn','record_content','内容'),(533,'zh_cn','record_prio','优先'),(534,'zh_cn','server_primary','主名称服务器'),(535,'zh_cn','server_name','名称服务器 FQDN'),(536,'zh_cn','server_description','描述'),(537,'zh_cn','server_type','服务器类型'),(538,'zh_cn','sync_status','同步状态'),(539,'zh_cn','server_details','服务器的详细信息'),(540,'zh_cn','api_auth_key','API 的身份验证密钥'),(541,'zh_cn','server_status','服务器状态'),(542,'zh_cn','sync_status_config','配置状态'),(543,'zh_cn','help_api_auth_key','此密钥值由系统中的脚本所定义(config-bind.php).'),(544,'zh_cn','sync_status_log','记录状态'),(545,'zh_cn','api','API （支持绑定）'),(546,'zh_cn','config_zone_defaults','区域配置默认值'),(547,'zh_cn','config_zone_database','区域数据库的默认设置'),(548,'zh_cn','config_dateandtime','日期和时间配置'),(549,'zh_cn','timestamp','时间戳'),(550,'zh_cn','username','用户名'),(551,'zh_cn','log_type','日志类型'),(552,'zh_cn','log_contents','日志内容'),(553,'zh_cn','filter_searchbox','搜索'),(554,'zh_cn','filter_num_logs_rows','最大日志行数'),(555,'zh_cn','filter_id_server_name','名称服务器'),(556,'zh_cn','filter_id_domain','域名'),(557,'zh_cn','help_ipv4_autofill','在域中，与指定的域的名称后缀的所有 Ip 自动都创建 PTR 记录。'),(558,'zh_cn','ipv4_help','注意'),(559,'zh_cn','help_ipv4_help','此接口允许您设置为 24 的反向 DNS 记录网络范围内，通过指定网络地址和 （可选） 域的 PTR 记录，如果你想要自动创建的所有 IP DNS 映射。'),(560,'zh_cn','domain_standard','标准域'),(561,'zh_cn','domain_reverse_ipv4','反向域名 (IPv4)'),(562,'zh_cn','domain_type','域类型'),(563,'zh_cn','ipv4_network','IPv4 网络地址'),(564,'zh_cn','ipv4_autofill','自动填充 IPs'),(565,'zh_cn','ipv4_autofill_domain','自动填充 IPs 与域'),(566,'zh_cn','reverse_ptr','反向 PTR'),(567,'zh_cn','file_bind_8','将绑定 8/9 兼容区域'),(568,'zh_cn','menu_domains_import','导入域'),(569,'zh_cn','records_not_imported','警告 ︰ 没有记录导入到应用程序 ！'),(570,'zh_cn','record_import_guide','下面显示从上载区域已由 NamedManager 处理的所有记录。仔细检查一切正确显示 — — 可能有一些记录，需要调整，或一些，不再是必需的 （如老 NS 记录）。\n\n你可以检查/取消选中导入按钮，以包含/排除来自导入过程的记录，如果他们不再需要。_All the records that have been processed by NamedManager from the uploaded zonefile are displayed below. Double-check that everything appears correctly - there may be some records that need adjusting, or some that are no longer required (eg old NS records).\n\nYou can check/uncheck the import button to include/exclude records from the import process if they are no longer desired.'),(571,'zh_cn','domain_delete','删除域'),(572,'zh_cn','delete_confirm','确认删除'),(573,'zh_cn','config_api','API 配置'),(574,'zh_cn','config_miscellaneous','杂项配置'),(575,'zh_cn','domain_records','域名记录'),(576,'zh_cn','record_header_type','类型'),(577,'zh_cn','record_header_ttl','TTL'),(578,'zh_cn','record_header_prio','优先'),(579,'zh_cn','record_header_name','名字的起源'),(580,'zh_cn','record_header_content','内容/记录'),(581,'zh_cn','record_header_import','导入记录吗？'),(582,'zh_cn','record_origin','名字的起源'),(583,'zh_cn','unmatched_import','不匹配的记录'),(584,'zh_cn','import_notice_unmatched_rows','并不是所有的记录被成功导入，请审查不匹配的行下面-如果他们需要，你可以调整之前上传文件的格式或创建域，然后添加这些错过的记录手��'),(585,'zh_cn','import_notice_no_unmatched_rows','已经确定并导入到上述数组区域文件中的所有记录。:-)'),(586,'zh_cn','upload','上传'),(587,'zh_cn','import_upload_type','导入源'),(588,'zh_cn','import_upload_file','区域文件'),(589,'zh_cn','help_admin_api_key','用于身份验证的名称服务器位于脚本的键。'),(590,'zh_cn','unmatched_import_help','区域导入并不总是完美的尤其是当从人权写入的文本区域文件导入。如果有任何不匹配的记录，将显示在下面的手动处理。'),(591,'zh_cn','server_record','使用作为 NS 记录'),(592,'zh_cn','server_record_option_help','将此域名服务器作为公共的 NS 记录添加到所有的域。'),(593,'zh_cn','ipv4_autofill_forward','创建正向记录'),(594,'zh_cn','help_ipv4_autofill_forward','自动为每个 IP 在指定域中创建转发记录。'),(595,'zh_cn','sync_status_zones','区域状态'),(596,'zh_cn','ipv4_autofill_reverse_from_forward','创建从现有的记录'),(597,'zh_cn','help_ipv4_autofill_reverse_from_forward','自动查找任何现有 IP 范围被记录添加和设置反向记录他们在可能的情况。'),(598,'zh_cn','help_domain_group_selection','选择的组或此域属于的组-组允许域位于特定组的名称服务器，用于隔离目的 （如内部 vs 外部名称服务器） 上。'),(599,'zh_cn','config_logging','日志记录配置'),(600,'zh_cn','domain_groups','域服务器组'),(601,'zh_cn','server_group','服务器组'),(602,'zh_cn','menu_servers_groups','管理服务器组'),(603,'zh_cn','menu_servers_groups_view','查看组'),(604,'zh_cn','menu_servers_groups_add','添加组'),(605,'zh_cn','group_name','名称'),(606,'zh_cn','group_description','描述'),(607,'zh_cn','group_members','服务器组成员'),(608,'zh_cn','group_details','服务器组的详细信息'),(609,'zh_cn','group_member_servers','成员名称服务器'),(610,'zh_cn','group_member_domains','域成员'),(611,'zh_cn','group_delete','删除组'),(612,'zh_cn','server_domains','服务器域设置'),(613,'zh_cn','realname','真实姓名'),(614,'zh_cn','contact_email','联系人电子邮件'),(615,'zh_cn','lastlogin_time','上次登录时间'),(616,'zh_cn','lastlogin_ipaddress','上次登录位置'),(617,'zh_cn','tbl_lnk_permissions','权限'),(618,'zh_cn','user_permissions','用户权限'),(619,'zh_cn','id_user','用户 ID'),(620,'zh_cn','user_view','用户详细信息'),(621,'zh_cn','user_password','用户密码'),(622,'zh_cn','user_info','用户详细信息'),(623,'zh_cn','user_options','用户选项'),(624,'zh_cn','user_delete','删除用户'),(625,'zh_cn','menu_admin_users','用户管理'),(626,'zh_cn','domain_reverse_ipv6','反向域名 (IPv6)'),(627,'zh_cn','ipv6_network','IPv6 网络范围'),(628,'zh_cn','ipv6_help','注意'),(629,'zh_cn','help_ipv6_help','此接口允许您通过指定 CIDR 值范围设置为 IPv6 网络范围的反向 DNS 记录。'),(630,'zh_cn','id_group','名称服务器组'),(631,'zh_cn','config_amberstats','协助开发人员 ！'),(632,'zh_cn','config_hosted','托管的云 DNS 服务');
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_avaliable`
--

DROP TABLE IF EXISTS `language_avaliable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_avaliable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_avaliable`
--

LOCK TABLES `language_avaliable` WRITE;
/*!40000 ALTER TABLE `language_avaliable` DISABLE KEYS */;
INSERT INTO `language_avaliable` (`id`, `name`) VALUES (1,'en_us'),(2,'zh_cn');
/*!40000 ALTER TABLE `language_avaliable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_server` int(11) NOT NULL DEFAULT '0',
  `id_domain` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `timestamp` bigint(20) NOT NULL,
  `log_type` char(10) NOT NULL DEFAULT '',
  `log_contents` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2802 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` (`id`, `id_server`, `id_domain`, `username`, `timestamp`, `log_type`, `log_contents`) VALUES (2795,0,0,'ppmoney',1524126462,'audit','Automated log retention clean completed, removed 33 records order than 2018-01-19'),(2796,0,0,'ppmoney',1524126462,'audit','Domain pp.local serial updated to 2018041901'),(2797,0,0,'ppmoney',1524126462,'audit','Updated nameserver (NS) records for pp.local'),(2798,0,0,'SYSTEM',1524126481,'server','Updated name server  to configuration version 1524126462 and reloaded'),(2799,0,0,'setup',1524289836,'audit','Automated log retention clean completed, removed 0 records order than 2018-01-21'),(2800,0,0,'setup',1524289836,'audit','Domain pp.local has been deleted.'),(2801,0,0,'setup',1524289841,'audit','Domain ppmoney.com has been deleted.');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL DEFAULT '0',
  `parent` varchar(50) NOT NULL,
  `topic` varchar(50) NOT NULL,
  `link` varchar(50) NOT NULL,
  `permid` int(11) NOT NULL DEFAULT '0',
  `config` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`id`, `priority`, `parent`, `topic`, `link`, `permid`, `config`) VALUES (170,100,'top','menu_overview','home.php',0,''),(171,200,'top','menu_logs','logs/logs.php',2,'FEATURE_LOGS_ENABLE'),(172,300,'top','menu_domains','domains/domains.php',2,''),(173,301,'menu_domains','menu_domains_view','domains/domains.php',2,''),(174,302,'menu_domains','menu_domains_add','domains/add.php',2,''),(175,310,'menu_domains_view','','domains/view.php',2,''),(176,310,'menu_domains_view','','domains/records.php',2,''),(177,310,'menu_domains_view','','domains/delete.php',2,''),(178,500,'top','menu_servers','servers/servers.php',2,''),(179,501,'menu_servers','menu_servers_view','servers/servers.php',2,''),(180,502,'menu_servers','menu_servers_add','servers/add.php',2,''),(181,510,'menu_servers_view','','servers/view.php',2,''),(182,510,'menu_servers_view','','servers/logs.php',2,''),(183,510,'menu_servers_view','','servers/delete.php',2,''),(184,900,'top','menu_configuration','admin/config.php',2,''),(185,320,'menu_domains','menu_domains_import','domains/import.php',2,''),(186,503,'menu_servers','menu_servers_groups','servers/groups.php',2,''),(187,520,'menu_servers_groups','menu_servers_groups_view','servers/groups.php',2,''),(188,521,'menu_servers_groups','menu_servers_groups_add','servers/group-add.php',2,''),(189,521,'menu_servers_groups_view','','servers/group-view.php',2,''),(190,521,'menu_servers_groups_view','','servers/group-delete.php',2,''),(191,920,'top','menu_admin_users','user/users.php',3,'AUTH_METHOD=sql'),(192,921,'menu_admin_users','','user/user-view.php',3,'AUTH_METHOD=sql'),(193,921,'menu_admin_users','','user/user-permissions.php',3,'AUTH_METHOD=sql'),(194,921,'menu_admin_users','','user/user-delete.php',3,'AUTH_METHOD=sql'),(195,921,'menu_admin_users','','user/user-add.php',3,'AUTH_METHOD=sql');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `name_servers`
--

DROP TABLE IF EXISTS `name_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `name_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_group` int(11) NOT NULL DEFAULT '1',
  `server_primary` tinyint(1) NOT NULL DEFAULT '0',
  `server_record` tinyint(1) NOT NULL DEFAULT '0',
  `server_name` varchar(255) NOT NULL DEFAULT '',
  `server_description` text NOT NULL,
  `server_type` varchar(20) NOT NULL DEFAULT '',
  `api_auth_key` varchar(255) NOT NULL DEFAULT '',
  `api_sync_config` bigint(20) NOT NULL DEFAULT '0',
  `api_sync_log` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_servers`
--

LOCK TABLES `name_servers` WRITE;
/*!40000 ALTER TABLE `name_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `name_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `name_servers_groups`
--

DROP TABLE IF EXISTS `name_servers_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `name_servers_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) CHARACTER SET ucs2 NOT NULL,
  `group_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_servers_groups`
--

LOCK TABLES `name_servers_groups` WRITE;
/*!40000 ALTER TABLE `name_servers_groups` DISABLE KEYS */;
INSERT INTO `name_servers_groups` (`id`, `group_name`, `group_description`) VALUES (2,'zhouzh','');
/*!40000 ALTER TABLE `name_servers_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Stores all the possible permissions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `value`, `description`) VALUES (1,'disabled','Enabling the disabled permission will prevent the user from being able to login.'),(2,'namedadmins','Full management over domains, records and application defaults.'),(3,'admin','Allows configuration of user accounts');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL DEFAULT '',
  `realname` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `password_salt` varchar(20) NOT NULL DEFAULT '',
  `contact_email` varchar(255) NOT NULL DEFAULT '',
  `time` bigint(20) NOT NULL DEFAULT '0',
  `ipaddress` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ipaddress` (`ipaddress`),
  KEY `time` (`time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='User authentication system.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `realname`, `password`, `password_salt`, `contact_email`, `time`, `ipaddress`) VALUES (1,'setup','Setup Account','14c2a5c3681b95582c3e01fc19f49853d9cdbb31','hctw8lbz3uhxl6sj8ixr','support@amberdms.com',1524289681,'192.168.120.33');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_blacklist`
--

DROP TABLE IF EXISTS `users_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) NOT NULL,
  `failedcount` int(11) NOT NULL DEFAULT '0',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Prevents automated login attacks.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_blacklist`
--

LOCK TABLES `users_blacklist` WRITE;
/*!40000 ALTER TABLE `users_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_options`
--

DROP TABLE IF EXISTS `users_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_options`
--

LOCK TABLES `users_options` WRITE;
/*!40000 ALTER TABLE `users_options` DISABLE KEYS */;
INSERT INTO `users_options` (`id`, `userid`, `name`, `value`) VALUES (47,3,'lang','zh_cn'),(48,3,'dateformat','yyyy-mm-dd'),(49,3,'shrink_tableoptions','on'),(50,3,'debug',''),(51,3,'concurrent_logins','on'),(52,1,'lang','zh_cn'),(53,1,'dateformat','yyyy-mm-dd'),(54,1,'shrink_tableoptions',''),(55,1,'default_employeeid',''),(56,1,'debug',''),(57,1,'concurrent_logins','');
/*!40000 ALTER TABLE `users_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_permissions`
--

DROP TABLE IF EXISTS `users_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `permid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='Stores user permissions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_permissions`
--

LOCK TABLES `users_permissions` WRITE;
/*!40000 ALTER TABLE `users_permissions` DISABLE KEYS */;
INSERT INTO `users_permissions` (`id`, `userid`, `permid`) VALUES (1,1,2),(2,1,3),(5,3,3),(6,3,2);
/*!40000 ALTER TABLE `users_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_sessions`
--

DROP TABLE IF EXISTS `users_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `authkey` varchar(40) NOT NULL,
  `ipv4` varchar(15) NOT NULL DEFAULT '',
  `ipv6` varchar(255) NOT NULL DEFAULT '',
  `time` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=271 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_sessions`
--

LOCK TABLES `users_sessions` WRITE;
/*!40000 ALTER TABLE `users_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-21 14:13:26
